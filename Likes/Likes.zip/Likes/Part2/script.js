function addlike1() {
    var likecounter = document.querySelector("#likesnumber1");
    likecounter.innerText++;
}

function addlike2() {
    var likecounter = document.querySelector("#likesnumber2");
    likecounter.innerText++;
}

function addlike3() {
    var likecounter = document.querySelector("#likesnumber3");
    likecounter.innerText++;
}