function addlike() {
    var likecounter = document.querySelector("#likesnumber");
    likecounter.innerText++;
}